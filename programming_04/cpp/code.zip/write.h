#ifndef WRITE_H
#define WRITE_H

int write(unsigned char mem[], FILE * ofp);

#endif
