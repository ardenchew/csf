#ifndef PROCESS_H
#define PROCESS_H

int process(FILE * rfp, FILE * ofp);

#endif
