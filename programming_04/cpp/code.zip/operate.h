#ifndef OPERATE_H
#define OPERATE_H

int get_byte(std::string opcode, long int arg, bool empty);

#endif
