#ifndef ERROR_H
#define ERROR_H

int get_error(int error, int writefile);

#endif
