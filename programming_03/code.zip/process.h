#ifndef PROCESS_H
#define PROCESS_H

int process(int encodings[], int byte_count, int writefile);

#endif
