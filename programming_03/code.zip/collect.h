#ifndef COLLECT_H
#define COLLECT_H

int collect(int *encodings, int readfile);

#endif
