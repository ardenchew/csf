#ifndef DUMP_H
#define DUMP_H

int dump(int encodings[], int byte_count, int dumpfile);

#endif
